"""Versioned research evidence and event ledger. Records are append-only; view.json is derived.
CLI: init | forecast | outcome | revise | review | export; mutation payloads use --input JSON.
No command downloads data, trades, or treats a supplied source as independently verified.
"""
from pathlib import Path
from datetime import datetime,timezone
from zoneinfo import ZoneInfo
import argparse,copy,hashlib,json,math,os

ROOT=Path(__file__).resolve().parent
DEFAULT=ROOT/'v4/evidence_system'
def now_iso():return datetime.now(timezone.utc).isoformat()
def parse(t):
    d=datetime.fromisoformat(t.replace('Z','+00:00'))
    if d.tzinfo is None:raise ValueError('Timezone is required')
    return d.astimezone(timezone.utc)
def canonical(x):return json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False)
def digest(x):return hashlib.sha256(canonical(x).encode()).hexdigest()
def load(path):return json.loads(Path(path).read_text(encoding='utf8'))

EVENT_LINKS={
 'SK_Q3':(['000660.KS','SKHY'],['DRAM'],['memory_cycle']),
 'MSFT_Q1':(['MSFT'],['QQQM','SMH','SOXX','DRAM'],['ai_monetization','capital_returns']),
 'GOOGL_Q3':(['GOOGL'],['QQQM','SMH','SOXX','DRAM'],['ai_monetization','capital_returns']),
 'AMZN_Q3':(['AMZN'],['QQQM','SMH','SOXX','DRAM'],['ai_monetization','capital_returns']),
 'FOMC':([],['QQQM','SMH','SOXX','DRAM'],['discount_rate']),
 'GDP_Q3_PCE_SEP':([],['QQQM','SMH','SOXX','DRAM'],['macro_demand','discount_rate']),
 'TSM_MONTHLY':(['TSM'],['SMH','SOXX','QQQM'],['ai_supply']),
 'META_Q3':(['META'],['QQQM'],['capital_returns'])}
THESIS_LABELS={'memory_cycle':'存储周期与正常化利润','ai_monetization':'AI付费与收入兑现',
 'capital_returns':'现金流、资本开支与每股回报','discount_rate':'通胀与估值折现率',
 'macro_demand':'美国真实需求','ai_supply':'AI供应与交付','unmapped':'新增证据待归类'}

def event_time(e):
    for k in ['singapore_time','decision_standard_singapore','call_singapore','pce_singapore']:
        if e.get(k):return e[k],('confirmed_release_time'if k=='pce_singapore'else 'standard_time_inferred'if k=='decision_standard_singapore'else 'call_time_release_may_precede')
    if e['id']=='MSFT_Q1':return '2026-10-29T04:00:00+08:00','after_close_window_start_not_exact_release'
    if e.get('date_local')and e.get('time_local'):
        d=datetime.fromisoformat(e['date_local']+'T'+e['time_local']).replace(tzinfo=ZoneInfo(e['timezone']))
        return d.isoformat(),'scheduled_update'
    return None,'already_reported_or_unknown'

def seed_events(snapshot,recorded_at):
    business={b['symbol']:b for b in snapshot['business']};result=[]
    for e in snapshot['events']:
        stamp,timing=event_time(e);companies,funds,theses=EVENT_LINKS.get(e['id'],([],[],['unmapped']))
        guides=[]
        for company in companies:
            b=business.get(company)
            if b and b.get('guidance'):guides.append({'company':company,'guidance':b['guidance'],'source_ids':b['source_ids'],'period':b.get('period'),'type':'management_guidance_from_prior_snapshot'})
        result.append({'event_id':e['id'],'scheduled_at':stamp,'timing_quality':timing,
          'event_status_at_snapshot':e['status'],'watch':e.get('watch',e.get('note','')),
          'source_ids':e.get('source_ids',[]),'companies':companies,'funds':funds,'thesis_ids':theses,
          'prior_guidance':guides,'forecast':None,'actual':None,'price_reaction':None,
          'recorded_at':recorded_at,'source_snapshot_retrieved_at':snapshot['retrieved_at'],
          'seed_type':'historical_evidence_import_not_a_forecast',
          'threshold_policy':'Management guidance is a reference bar, not verified market consensus. Qualitative triggers require analyst review.',
          'decision_mapping':{'support':'经营兑现且现金回报未恶化：重新核对盈利与估值假设，再检查买价。',
                              'adverse':'盈利、现金回报或贴现率恶化：降低相关盈利/倍数假设并重新计算。',
                              'unknown':'保留待核实状态，不自动生成买入指令。'}})
    return result

def numerical_diff(old,new,path='',include_text=False):
    out=[]
    if (isinstance(old,dict)and (isinstance(new,dict)or new is None))or(isinstance(new,dict)and old is None):
        old=old or {};new=new or {}
        for k in sorted(set(old)|set(new)):out+=numerical_diff(old.get(k),new.get(k),path+'/'+k,include_text)
    elif (isinstance(old,list)and (isinstance(new,list)or new is None))or(isinstance(new,list)and old is None):
        old=old or [];new=new or []
        # Stable identity joins avoid list reordering being mistaken for a fundamental change.
        key=next((k for k in ['symbol','id'] if all(isinstance(x,dict)and k in x for x in old+new)),None)
        if key:
            a={x[key]:x for x in old};b={x[key]:x for x in new}
            for k in sorted(set(a)|set(b)):out+=numerical_diff(a.get(k),b.get(k),path+'/'+str(k),include_text)
        else:
            for i in range(max(len(old),len(new))):out+=numerical_diff(old[i]if i<len(old)else None,new[i]if i<len(new)else None,path+'/'+str(i),include_text)
    elif old!=new and (include_text or isinstance(old,(int,float))and not isinstance(old,bool)or isinstance(new,(int,float))and not isinstance(new,bool)):
        companies=[];theses=[]
        if path.startswith('/business/'):
            company=path.split('/')[2];companies=[company];theses=['capital_returns','memory_cycle'if company in ['MU','SKHY','SAMSUNG','000660.KS','005930.KS']else'ai_monetization']
        elif path.startswith('/macro/'):theses=['discount_rate','macro_demand']
        elif path.startswith('/positioning/'):theses=['discount_rate']
        else:theses=['unmapped']
        events=[e for e,(co,_,ts)in EVENT_LINKS.items()if set(companies)&set(co)or set(theses)&set(ts)]
        out.append({'path':path,'old':old,'new':new,'companies':companies,'thesis_ids':theses,'event_ids':events,
                    'conclusion_effect':'requires_review_not_automatic_direction'})
    return out

def read_records(folder=DEFAULT):
    paths=sorted((Path(folder)/'records').glob('*.json'));records=[];previous=None
    for i,p in enumerate(paths,1):
        r=load(p);h=r.pop('record_hash')
        if r['sequence']!=i or r['previous_hash']!=previous or digest(r)!=h:raise ValueError('Ledger integrity failure: '+p.name)
        r['record_hash']=h;records.append(r);previous=h
    return records

def append_record(kind,payload,folder=DEFAULT,recorded_at=None):
    folder=Path(folder);(folder/'records').mkdir(parents=True,exist_ok=True)
    # O_EXCL serializes writers; never overwrite an existing record.
    lock=folder/'write.lock';fd=os.open(lock,os.O_CREAT|os.O_EXCL|os.O_WRONLY)
    try:
        records=read_records(folder);stamp=recorded_at or now_iso();parse(stamp)
        if records and parse(stamp)<parse(records[-1]['recorded_at']):raise ValueError('Cannot backdate a ledger record')
        r={'sequence':len(records)+1,'recorded_at':stamp,'kind':kind,'payload':payload,'previous_hash':records[-1]['record_hash']if records else None}
        r['record_hash']=digest(r);p=folder/'records'/f"{r['sequence']:06d}_{r['record_hash'][:12]}.json"
        with p.open('x',encoding='utf8')as f:json.dump(r,f,ensure_ascii=False,indent=2,allow_nan=False)
        return r
    finally:
        os.close(fd);lock.unlink()

def provenance(payload):
    p=payload.get('provenance',{})
    for k in ['source_url','retrieved_at']:
        if not p.get(k):raise ValueError('provenance requires '+k)
    if not p['source_url'].startswith(('https://','http://')):raise ValueError('source_url must be public URL')
    parse(p['retrieved_at'])
    if p.get('published_at'):parse(p['published_at'])
    elif p.get('published_date'):
        datetime.strptime(p['published_date'],'%Y-%m-%d');ZoneInfo(p.get('published_timezone','UTC'))
    else:raise ValueError('provenance requires published_at or a published_date with timezone')
    return p

def initialize(snapshot,folder=DEFAULT,recorded_at=None):
    if read_records(folder):raise ValueError('Ledger already initialized')
    stamp=recorded_at or now_iso()
    return append_record('initialize',{'snapshot':snapshot,'snapshot_hash':digest(snapshot),'events':seed_events(snapshot,stamp)},folder,stamp)

def record_action(kind,payload,folder=DEFAULT,recorded_at=None):
    stamp=recorded_at or now_iso();records=read_records(folder)
    if not records:raise ValueError('Initialize first')
    view=build_view(folder,stamp);p=copy.deepcopy(payload)
    if kind in ['forecast','outcome']:
        event=next((e for e in view['events']if e['event_id']==p.get('event_id')),None)
        if not event:raise ValueError('Unknown event_id')
        if kind=='forecast':
            for field in ['expectation','metric','basis','threshold','decision_if_above','decision_if_below','rationale']:
                if field not in p or p[field] is None:raise ValueError('Forecast requires '+field)
            # Call times are not trusted release times; pre-call does not prove pre-release.
            p['prospective_eligibility']=('eligible_by_verified_schedule'if event['timing_quality']=='confirmed_release_time'and parse(stamp)<parse(event['scheduled_at'])else'not_established')
            if event.get('actual')or event['event_status_at_snapshot']=='already_reported':p['prospective_eligibility']='not_eligible_after_recorded_outcome'
            p['timing_note']='Recorded now, never backdated. Eligibility can be revoked by actual release timing.'
        else:
            provenance(p)
            if 'actual'not in p or p['actual']is None:raise ValueError('Outcome requires actual')
            if p.get('released_at'):
                if parse(p['released_at'])>parse(stamp):raise ValueError('Cannot record a future actual outcome')
            elif p.get('released_date'):
                day=datetime.strptime(p['released_date'],'%Y-%m-%d').replace(tzinfo=ZoneInfo(p.get('release_timezone','UTC')))
                if day>parse(stamp):raise ValueError('Cannot record a future actual outcome')
                p['release_time_precision']='day_only_exact_release_unknown'
            else:raise ValueError('Outcome requires released_at or released_date; never invent an exact release time')
            p['verification_status']='user_supplied_source_requires_analyst_review'
    elif kind=='evidence_revision':
        provenance(p)
        if not p.get('reason')or not isinstance(p.get('snapshot'),dict):raise ValueError('Revision requires snapshot and reason')
        previous=view['snapshot'];p['previous_snapshot_hash']=digest(previous);p['snapshot_hash']=digest(p['snapshot'])
        p['numerical_changes']=numerical_diff(previous,p['snapshot'])
        number_paths={r['path']for r in p['numerical_changes']}
        p['qualitative_changes']=[r for r in numerical_diff(previous,p['snapshot'],include_text=True)if r['path']not in number_paths]
        p['verification_status']='supplied_revision_not_independently_verified'
    elif kind=='analyst_review':
        for k in ['reviewer','rationale','conclusion','valid_until','snapshot_hash','acknowledged_head_hash']:
            if not p.get(k):raise ValueError('Review requires '+k)
        if p['snapshot_hash']!=view['snapshot_hash']or p['acknowledged_head_hash']!=records[-1]['record_hash']:raise ValueError('Review does not acknowledge latest evidence ledger')
        if parse(p['valid_until'])<=parse(stamp):raise ValueError('Review expiry must be in the future')
    else:raise ValueError('Unsupported kind')
    if kind in ['outcome','evidence_revision']:
        prov=p['provenance']
        published=parse(prov['published_at'])if prov.get('published_at')else datetime.strptime(prov['published_date'],'%Y-%m-%d').replace(tzinfo=ZoneInfo(prov.get('published_timezone','UTC')))
        if published>parse(stamp)or parse(prov['retrieved_at'])>parse(stamp):raise ValueError('Source timestamps cannot be in the future')
    return append_record(kind,p,folder,stamp)

def build_view(folder=DEFAULT,asof=None):
    stamp=asof or now_iso();clock=parse(stamp)
    # Validate the complete chain, then reconstruct only information recorded by asof.
    records=[r for r in read_records(folder)if parse(r['recorded_at'])<=clock]
    if not records:raise ValueError('Empty ledger')
    initial=records[0]['payload'];snapshot=initial['snapshot'];events=copy.deepcopy(initial['events'])
    byid={e['event_id']:e for e in events};changes=[];text_changes=[];last_review=None;latest_evidence_sequence=1
    for r in records[1:]:
        k=r['kind'];p=r['payload']
        if k=='forecast':byid[p['event_id']]['forecast']={**p,'recorded_at':r['recorded_at'],'record_hash':r['record_hash']};latest_evidence_sequence=r['sequence']
        elif k=='outcome':
            byid[p['event_id']]['actual']={**p,'recorded_at':r['recorded_at'],'record_hash':r['record_hash']};latest_evidence_sequence=r['sequence']
        elif k=='evidence_revision':
            snapshot=p['snapshot'];changes.extend([{**x,'record_hash':r['record_hash'],'recorded_at':r['recorded_at']}for x in p['numerical_changes']]);latest_evidence_sequence=r['sequence']
            text_changes.extend([{**x,'record_hash':r['record_hash'],'recorded_at':r['recorded_at']}for x in p.get('qualitative_changes',[])])
            revised=seed_events(snapshot,r['recorded_at'])
            for e in revised:
                if e['event_id']in byid:
                    for field in ['forecast','actual','price_reaction']:e[field]=byid[e['event_id']][field]
                    e['current_reference_guidance']=e['prior_guidance']
                    e['prior_guidance']=byid[e['event_id']]['prior_guidance']
                    e['prior_guidance_asof_recorded_at']=byid[e['event_id']]['recorded_at']
                    e['recorded_at']=byid[e['event_id']]['recorded_at']
            events=revised;byid={e['event_id']:e for e in events}
        elif k=='analyst_review':last_review=r
    blockers=[]
    if not last_review:blockers.append('尚无显式分析复核；导入证据不自动成为当前投资结论。')
    elif last_review['sequence']<latest_evidence_sequence:blockers.append('复核后已有新证据或事件结果，需要再次审阅。')
    elif parse(last_review['payload']['valid_until'])<=clock:blockers.append('分析复核已超过有效期。')
    for e in events:
        scheduled=e['scheduled_at'];due=scheduled is not None and parse(scheduled)<=clock
        e['status']='outcome_recorded'if e['actual']else'already_reported_in_import'if e['event_status_at_snapshot']=='already_reported'else'due_unreviewed'if due else'pending'
        if due and not e['actual']:blockers.append(e['event_id']+' 已到复核时间，尚无已记录结果。')
        f=e['forecast'];a=e['actual']
        if f and a:
            e['forecast_preceded_actual_release']=(parse(f['recorded_at'])<parse(a['released_at']))if a.get('released_at')else None
            e['numeric_forecast_error']=a['actual']-f['expectation']if e['forecast_preceded_actual_release']is True and isinstance(a['actual'],(int,float))and not isinstance(a['actual'],bool)and isinstance(f['expectation'],(int,float))and not isinstance(f['expectation'],bool)and a.get('metric')==f.get('metric')else None
        else:e['forecast_preceded_actual_release']=None;e['numeric_forecast_error']=None
    for c in changes+text_changes:
        if any(s in ['000660.KS','005930.KS']for s in c['companies']):
            c['recorded_thesis_ids']=c['thesis_ids'];c['thesis_ids']=['capital_returns','memory_cycle']
            c['event_ids']=[e for e,(co,_,ts)in EVENT_LINKS.items()if set(c['companies'])&set(co)or set(c['thesis_ids'])&set(ts)]
            c['linkage_note']='Derived view resolves listed-company aliases; original append-only linkage remains in record.'
    return {'schema':'v4.evidence_view.v1','generated_at':stamp,'ledger_head_hash':records[-1]['record_hash'],'record_count':len(records),
      'snapshot_hash':digest(snapshot),'snapshot':snapshot,'events':events,'numerical_changes':changes,'qualitative_changes':text_changes,
      'theses':[{'id':k,'label':v,'needs_review':bool(blockers),'linked_changes':sum(k in c['thesis_ids']for c in changes)}for k,v in THESIS_LABELS.items()],
      'active_conclusion_allowed':not blockers,'blockers':blockers,
      'active_conclusion':last_review['payload']['conclusion']if last_review and not blockers else None,
      'last_review':last_review,'scope':'Evidence and forecast audit trail; no automatic causal interpretation, verification of supplied sources, or buy signal.'}

def export(folder=DEFAULT):
    v=build_view(folder);p=Path(folder)/'view.json';p.write_text(json.dumps(v,ensure_ascii=False,indent=2,allow_nan=False),encoding='utf8');return p

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('command',choices=['init','forecast','outcome','revise','review','export']);p.add_argument('--input');p.add_argument('--folder',default=str(DEFAULT));a=p.parse_args()
    if a.command=='init':initialize(load(a.input or ROOT/'v3/current_evidence.json'),a.folder)
    elif a.command!='export':
        if not a.input:p.error('--input is required')
        record_action({'revise':'evidence_revision','review':'analyst_review'}.get(a.command,a.command),load(a.input),a.folder)
    print(export(a.folder))
