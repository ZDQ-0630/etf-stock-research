from pathlib import Path
import json,tempfile,unittest
import monitor_runtime as m

class RuntimeTests(unittest.TestCase):
    def test_recovery_requires_staleness_and_owner_confirmation(self):
        m.begin('market_check',self.folder,self.t,'a')
        with self.assertRaises(ValueError):m.recover('a','test',self.folder,'2026-10-28T04:01:00Z',True)
        with self.assertRaises(ValueError):m.recover('a','test',self.folder,'2026-10-28T06:00:00Z',False)
        m.recover('a','operator verified abandoned',self.folder,'2026-10-28T06:00:00Z',True)
        self.assertFalse((self.folder/'active.lock').exists());self.assertIn('Abandoned',m.view(self.folder,'2026-10-28T06:01:00Z')['last_error'])
    def setUp(self):self.tmp=tempfile.TemporaryDirectory();self.folder=Path(self.tmp.name);self.t='2026-10-28T04:00:00Z'
    def tearDown(self):self.tmp.cleanup()
    def source(self,ok=True):return {'name':'official test','url':'https://example.org/','ok':ok,'content_checked':True,'error':None if ok else 'HTTP403'}
    def market(self,sources=None):return {'sources':sources or[self.source()],'content_review_performed':True,'review_summary':'Synthetic test, not real news coverage'}
    def test_overlapping_begin_rejected(self):
        m.begin('market_check',self.folder,self.t,'one')
        with self.assertRaises(RuntimeError):m.begin('market_check',self.folder,self.t,'two')
    def test_probe_does_not_become_market_success(self):
        m.begin('source_readiness',self.folder,self.t,'p');m.terminal('p',{'sources':[self.source()]},self.folder,'2026-10-28T04:01:00Z')
        v=m.view(self.folder,'2026-10-28T04:02:00Z');self.assertIsNone(v['last_success_at']);self.assertIsNone(v['last_market_check_at']);self.assertEqual(v['source_probe_outcome'],'succeeded')
    def test_completed_market_has_success_and_stale_after(self):
        m.begin('market_check',self.folder,self.t,'a');m.terminal('a',self.market(),self.folder,'2026-10-28T04:01:00Z')
        v=m.view(self.folder,'2026-10-28T04:02:00Z');self.assertEqual(v['status'],'healthy');self.assertEqual(v['stale_after'],'2026-10-28T05:31:00+00:00')
    def test_access_only_cannot_claim_market_scan(self):
        m.begin('market_check',self.folder,self.t,'a')
        with self.assertRaises(ValueError):m.terminal('a',{'sources':[self.source()]},self.folder,'2026-10-28T04:01:00Z')
    def test_failed_sources_preserved_partial_not_success(self):
        m.begin('market_check',self.folder,self.t,'a');m.terminal('a',self.market([self.source(),self.source(False)]),self.folder,'2026-10-28T04:01:00Z')
        v=m.view(self.folder,'2026-10-28T04:02:00Z');self.assertIsNone(v['last_success_at']);self.assertEqual(len(v['failed_sources']),1)
    def test_failure_clears_own_lock_and_keeps_error(self):
        m.begin('market_check',self.folder,self.t,'a');m.terminal('a',{},self.folder,'2026-10-28T04:01:00Z',forced_error='network unavailable')
        self.assertFalse((self.folder/'active.lock').exists());self.assertEqual(m.view(self.folder,'2026-10-28T04:02:00Z')['last_error'],'network unavailable')
    def test_wrong_run_cannot_finish(self):
        m.begin('market_check',self.folder,self.t,'a')
        with self.assertRaises(ValueError):m.terminal('wrong',self.market(),self.folder,self.t)
    def test_records_append_never_overwrite(self):
        m.begin('market_check',self.folder,self.t,'a');p=next((self.folder/'records').glob('*.json'));old=p.read_bytes();m.terminal('a',self.market(),self.folder,'2026-10-28T04:01:00Z');self.assertEqual(old,p.read_bytes());self.assertEqual(len(m.records(self.folder)),2)
    def test_hash_tampering_rejected(self):
        m.begin('market_check',self.folder,self.t,'a');p=next((self.folder/'records').glob('*.json'));r=m.load(p);r['payload']['scope']='fake';p.write_text(json.dumps(r),encoding='utf8')
        with self.assertRaises(ValueError):m.records(self.folder)
    def test_past_view_cannot_see_later_success(self):
        m.begin('market_check',self.folder,self.t,'a');m.terminal('a',self.market(),self.folder,'2026-10-28T04:01:00Z');v=m.view(self.folder,self.t);self.assertEqual(v['status'],'running');self.assertIsNone(v['last_success_at'])
    def test_stale_success_and_stale_running(self):
        m.begin('market_check',self.folder,self.t,'a');m.terminal('a',self.market(),self.folder,'2026-10-28T04:01:00Z');self.assertEqual(m.view(self.folder,'2026-10-28T06:00:00Z')['status'],'stale')
        m.begin('market_check',self.folder,'2026-10-28T06:01:00Z','b');self.assertEqual(m.view(self.folder,'2026-10-28T08:00:00Z')['status'],'running_stale')
    def test_reused_id_and_backdate_rejected(self):
        m.begin('market_check',self.folder,self.t,'a');m.terminal('a',self.market(),self.folder,'2026-10-28T04:01:00Z')
        with self.assertRaises(ValueError):m.begin('market_check',self.folder,'2026-10-28T04:02:00Z','a')
        with self.assertRaises(ValueError):m.begin('market_check',self.folder,'2026-10-28T03:59:00Z','b')
    def test_missing_content_review_per_source_rejected(self):
        m.begin('market_check',self.folder,self.t,'a');source=self.source();source['content_checked']=False
        with self.assertRaises(ValueError):m.terminal('a',self.market([source]),self.folder,'2026-10-28T04:01:00Z')

if __name__=='__main__':unittest.main(verbosity=2)
