# V6：Claude反馈的来源与范围核查

范围：读取现有源码、冻结的V3产物及基金/IRS官方资料；没有重跑全量回测，没有判定个人税务身份。核查日期为2026-10-28新加坡时间，实际取回时间见fund_costs.json。

## 官方费率

| 美国上市ETF | 当前可核实年费率 | 官方披露口径 | 官方来源/时点 |
|---|---:|---|---|
| QQQM | 0.15% | Total expense ratio；management fee同为0.15% | Invesco Q3 2026事实表，截至2026-09-30；本次重开官方PDF确认 |
| SMH | 0.35% | Total Expense Ratio | VanEck美国SMH产品页，本次可读页面市场资料截至2026-10-27，费率自身未单列有效日期 |
| SOXX | 0.33% | Expense Ratio（招募说明书费用）；management fee同为0.33% | iShares美国SOXX产品页及2026-09-30事实表；旧0.34%/0.35%不可替代当前0.33% |
| DRAM | 0.65% | Gross expense ratio（官网FAQ明确） | Roundhill美国DRAM产品页；费率自身未单列有效日期 |
| VOO | 0.03% | Expense ratio，按最近招募说明书披露 | Vanguard最新官方事实表，截至2026-09-30，本次重新打开确认 |
| VUG | 0.03% | Expense ratio，按最近招募说明书披露 | Vanguard最新官方事实表，截至2026-09-30；2026-02-01从0.04%下调的公告亦可核对 |
| QQQ | 0.18% | Total expense ratio | Invesco QQQ官网明确列示0.18%，不采用旧0.20% |

费率是年率小数0.0015/0.0035/0.0033/0.0065。不是买卖各扣一次的佣金。基金历史NAV/收益已反映基金费用，不应在历史ETF收益上重复扣TER。若将成分盈利构造的毛价格情景转成基金净情景，需要显式补费用；若输入的终值已经是基金净价格，再补扣会双算。用(1−费率)^年数是固定费率的近似情景，不是逐日会计精算。

网站另外三个选项对应小数为VOO0.0003、VUG0.0003、QQQ0.0018，不能缺失时默认为0。最新VUG事实表名称为Vanguard Morningstar Growth ETF；费用核实不等于验证该基金历史指数方法始终不变。

DRAM发行人为Roundhill，2026-04-02开始交易，官网说明持仓权重合并直接股票和总回报互换，并说明互换用于RIC分散化测试。0.65%不能被描述成所有交易/融资摩擦的完整预测：本轮未核实互换融资成本或其他交易成本是否及如何包含于该比率，字段保留null，未填0。官网Summary Prospectus链接本次浏览读取超时，不能冒充完整费用审计。

## 税：身份依赖，不能按计价币种代填

IRS官方说明：向非居民外国人支付的美国来源股息通常按30%或适用的较低条约税率预扣；条约待遇依赖具体资格、条约居民身份及向扣缴义务人提交的W-8BEN等。这个一般规则不等于给本用户确定税率，也不能把所有基金分配自动归为同一种应税股息。

SGD计价只说明模型货币单位，不能推出新加坡税务居民、非美国税务身份或条约资格。模型的个人适用预扣税率应保持未知，不能由学校、所在地或预算币种自动填30%/10%/15%。本轮未核实个人所得税、资本利得及遗产税适用情况。

## 三年检验：Claude的页面范围判断需要纠正

V3并非完全没有三年计算。`v3_run.py`第62行起明确包括`3calendar`前向标签，`calendar_endpoint`使用日历三年后首个可用交易日；实际产物在`v3/model/state_distributions.json`。同一当前回撤桶、period=all、horizon=3calendar的冻结数目如下：

| 标的 | 成熟日度观察 | 贪心不重叠窗口 | 未成熟观察 |
|---|---:|---:|---:|
| QQQ | 563 | 4 | 116 |
| QQQM | 125 | 1 | 116 |
| SMH | 167 | 4 | 69 |
| SOXX | 2,894 | 7 | 108 |
| DRAM | 0 | 0 | 80 |

这些是不重叠窗口数，不能称独立危机数或有效统计样本数。QQQM和DRAM证据不足的批评成立；“完全不对三年做经验检验”不符合现有代码和产物。更准确的说法是：已有探索性三年历史描述和策略比较，但不能验证新前瞻假设或未来三年收益。

策略比较还有更长共同终点：最后一笔计划月度分批入场再持有三日历年（`v3_config.json.minimum_calendar_holding_years=3`）。`v3/model/comparison_summary.json`中period=all、strategy=wait21的配对评估数为QQQ4、QQQM1、SMH3、SOXX6，DRAM因无成熟三年比较而明确跳过。它们与上表前向分布的计数不同，不能互换。所有股票组也有重叠风险，不能跨基金简单相加。

网站简洁历史页只有63/126/252选项，确实使外部审阅者漏看三年产物。应将三年结果与不足直接静态展示，避免让“代码里有”代替用户可见的说明。

同一当前桶只取2020年起的三年前向观察，QQQ为165日/非重叠2，QQQM125/1，SMH53/2，SOXX310/2，DRAM0/0。日度观察量不能掩盖实际可比较长窗口很少的问题。

## 历史状态与回报口径：没有发现分桶实现不一致

`v3_engine.py.state_frame`用`close.cummax()`定义峰值，再用`close/peak−1`分桶；`forward_labels`的进一步低点及close_return也用close，同时另存adjusted_return。三日历年分支采用相同close风险口径并另存adjusted_return。浏览器`ResearchMath.states/distribution`同样采用close。故“网站和V3的回撤状态不一致”未在源码中成立。

策略`wealth`用复权开盘`aopen`和`adj`评估投资业绩，是另一个指标，不应与价格风险分布混称相同收益。这种区分本身可以成立，前提是页面明确“价格回撤/价格收益”和“含分配调整的策略业绩”。若另研究总回报财富回撤，应作为单独敏感性口径，不能悄悄重写既有价格分桶或把两种历史拼接成一个序列。

## C0与FX：确认实现和标签分开

`v4_execution.py`与`model.js`的执行函数先做：USD本金 = SGD预算×(1−换汇比例)/fx0。随后扣股票成本和固定美元费用，形成的`cash`/`cash_usd`是USD余款。USD余款先计息，期末与股票卖出所得一起乘fxT，未见把SGD余款再次乘FX的重复换汇。

fx0/fxT实际单位为“每1 USD的SGD数”。当前界面“SGD/USD”容易与市场货币对惯例混淆，Claude此点成立。建议改为“每1美元对应的新币（SGD per USD；市场报价USD/SGD）”。仅检查正数无法识别用户填倒数；应明确单位并提供倒数核对，不应因未来汇率偏离1.3就硬拒绝合理情景。

## 对其他关键判断的限定

- 默认增长偏乐观、未明确TTM/NTM基准及财年错配，是实质设计风险。机械替换成某个“历史基准率中位数”并不会自动解决，它也必须有可比公司/期间/指标资料；一致预期也不是严格上界。
- “几乎不可能说不买”表述过强：Claude自己的DRAM例子就不满足10%门槛，QQQM接近边界；提高目标回报或缩小终值倍数也可令其他情景不满足。更准确的批评是：预填值支配结果，不能把条件满足写成买入信号。
- 费用和分红遗漏需要补充，但不能在已净费率的历史ETF收益上再扣费，也不能把SEC yield当未来现金分红预测。对股息的税务处理必须可追踪到假设或实际身份。
- 新基金不等于一定小规模或高价差。DRAM流动性、互换及清盘风险需要各自证据；不能仅从成立时间推出“默认5bp肯定太低”。本轮未核实可执行买卖价差，不将其填为已知事实。
- Claude没有读到JS实现和动态数表，所以其确定错误范围应限于可见文档，不能被当作已执行代码审计。把关键源码和数据做成静态文本/HTML是可以直接修复的可审阅性问题。

## 官方原文

- QQQM事实表：https://www.invesco.com/us-rest/contentdetail?contentId=5b4d8e58e0737710VgnVCM1000006e36b50aRCRD
- SMH美国产品页：https://www.vaneck.com/us/en/investments/semiconductor-etf-smh/
- SOXX美国产品页：https://www.ishares.com/us/products/239705/ishares-phlx-semiconductor-etf
- DRAM产品页与FAQ：https://www.roundhillinvestments.com/etf/dram/
- VOO事实表：https://workplace.vanguard.com/assets/corp/fund_communications/pdf_publish/us-products/fact-sheet/F0968.pdf
- VUG事实表：https://workplace.vanguard.com/assets/corp/fund_communications/pdf_publish/us-products/fact-sheet/F0967.pdf
- Vanguard费用下调公告：https://investor.vanguard.com/investor-resources-education/news/vanguard-lowers-expense-ratios-long-term-investing
- QQQ官网：https://www.invesco.com/qqq-etf/en/home.html
- IRS股息扣缴：https://www.irs.gov/individuals/international-taxpayers/federal-income-tax-withholding-and-reporting-on-other-kinds-of-us-source-income-paid-to-nonresident-aliens
- IRS条约待遇：https://www.irs.gov/individuals/international-taxpayers/claiming-tax-treaty-benefits
- IRS W-8BEN说明：https://www.irs.gov/instructions/iw8ben
