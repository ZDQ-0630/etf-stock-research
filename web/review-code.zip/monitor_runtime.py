"""Append-only monitor execution health. Access probes are never market scans.

CLI: probe | status | begin | finish | fail. All timestamps are real UTC by default.
This module never writes financial facts or changes investment assumptions.
"""
from pathlib import Path
from datetime import datetime, timezone, timedelta
from concurrent.futures import ThreadPoolExecutor
import argparse, hashlib, json, os, uuid, urllib.request, urllib.error

ROOT=Path(__file__).resolve().parent
DEFAULT=ROOT/'v5/monitor_runtime'
KINDS={'source_readiness','market_check'}
def utcnow():return datetime.now(timezone.utc).isoformat()
def parse(value):
    d=datetime.fromisoformat(value.replace('Z','+00:00'))
    if d.tzinfo is None:raise ValueError('Timestamp must include timezone')
    return d.astimezone(timezone.utc)
def canonical(value):return json.dumps(value,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False)
def digest(value):return hashlib.sha256(canonical(value).encode()).hexdigest()
def load(path):return json.loads(Path(path).read_text(encoding='utf8'))
def atomic_json(path,value):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    temporary=path.with_name(path.name+'.'+uuid.uuid4().hex+'.tmp')
    with temporary.open('x',encoding='utf8')as f:json.dump(value,f,ensure_ascii=False,indent=2,allow_nan=False)
    os.replace(temporary,path)

def records(folder=DEFAULT):
    out=[];head=None
    for i,path in enumerate(sorted((Path(folder)/'records').glob('*.json')),1):
        r=load(path);actual=r.pop('record_hash')
        if r['sequence']!=i or r['previous_hash']!=head or digest(r)!=actual:raise ValueError('Monitor log integrity failure: '+path.name)
        if out and parse(r['recorded_at'])<parse(out[-1]['recorded_at']):raise ValueError('Monitor record clock moved backwards')
        r['record_hash']=actual;out.append(r);head=actual
    return out

def append(kind,payload,folder=DEFAULT,at=None):
    folder=Path(folder);(folder/'records').mkdir(parents=True,exist_ok=True)
    writer=folder/'writer.lock';fd=os.open(writer,os.O_CREAT|os.O_EXCL|os.O_WRONLY)
    try:
        old=records(folder);stamp=at or utcnow();parse(stamp)
        if old and parse(stamp)<parse(old[-1]['recorded_at']):raise ValueError('Cannot backdate monitor execution')
        row={'sequence':len(old)+1,'kind':kind,'recorded_at':stamp,'payload':payload,'previous_hash':old[-1]['record_hash']if old else None}
        row['record_hash']=digest(row)
        path=folder/'records'/f"{row['sequence']:06d}_{row['record_hash'][:12]}.json"
        with path.open('x',encoding='utf8')as f:json.dump(row,f,ensure_ascii=False,indent=2,allow_nan=False)
        return row
    finally:os.close(fd);writer.unlink()

def begin(kind,folder=DEFAULT,at=None,run_id=None):
    if kind not in KINDS:raise ValueError('Unknown monitor run kind')
    folder=Path(folder);folder.mkdir(parents=True,exist_ok=True);lock=folder/'active.lock'
    rid=run_id or uuid.uuid4().hex;stamp=at or utcnow();parse(stamp)
    if any(r['payload'].get('run_id')==rid for r in records(folder)):raise ValueError('Run ID already exists')
    try:fd=os.open(lock,os.O_CREAT|os.O_EXCL|os.O_WRONLY)
    except FileExistsError:raise RuntimeError('A monitor run is already active; inspect status before explicit recovery')from None
    try:
        with os.fdopen(fd,'w',encoding='utf8')as f:json.dump({'run_id':rid,'kind':kind,'started_at':stamp},f)
        return append('begin',{'run_id':rid,'scope':kind},folder,stamp)
    except Exception:
        lock.unlink(missing_ok=True);raise

def terminal(run_id,payload,folder=DEFAULT,at=None,forced_error=None):
    folder=Path(folder);lock=folder/'active.lock'
    if not lock.exists()or load(lock)['run_id']!=run_id:raise ValueError('Terminal action must match the active run')
    active=load(lock);kind=active['kind'];data=dict(payload or {});sources=data.get('sources',[])
    if not isinstance(sources,list)or any(not isinstance(s,dict)or not s.get('name')or not s.get('url')or not isinstance(s.get('ok'),bool)for s in sources):raise ValueError('Sources require name, URL and explicit boolean ok')
    if kind=='market_check'and not forced_error:
        if data.get('content_review_performed')is not True or not data.get('review_summary')or not sources:raise ValueError('A market scan requires actual content review and coverage, not an access probe')
        if any(s['ok']and s.get('content_checked')is not True for s in sources):raise ValueError('Reachable does not mean news content checked')
    failures=[s for s in sources if not s['ok']]
    outcome='failed'if forced_error or not sources or len(failures)==len(sources)else'partial'if failures else'succeeded'
    if forced_error:data['error']=str(forced_error)
    data.update(run_id=run_id,scope=kind,outcome=outcome)
    row=append('terminal',data,folder,at)
    # Never clear a newer writer's lock, even after an unexpected external action.
    if lock.exists()and load(lock)['run_id']==run_id:lock.unlink()
    return row

def view(folder=DEFAULT,at=None,cadence_minutes=30):
    stamp=at or utcnow();clock=parse(stamp);rows=[r for r in records(folder)if parse(r['recorded_at'])<=clock]
    beginnings=[r for r in rows if r['kind']=='begin'];finished=[r for r in rows if r['kind']=='terminal']
    closed={r['payload']['run_id']for r in finished};running=next((r for r in reversed(beginnings)if r['payload']['run_id']not in closed),None)
    markets=[r for r in finished if r['payload']['scope']=='market_check'];probes=[r for r in finished if r['payload']['scope']=='source_readiness']
    successes=[r for r in markets if r['payload']['outcome']=='succeeded'];latest=finished[-1]if finished else None
    last_success=successes[-1]['recorded_at']if successes else None;stale_minutes=max(90,cadence_minutes*3)
    stale_after=(parse(last_success)+timedelta(minutes=stale_minutes)).isoformat()if last_success else None
    failures=[{'name':s['name'],'url':s['url'],'http_status':s.get('http_status'),'error':s.get('error')}for s in latest['payload'].get('sources',[])if not s['ok']]if latest else[]
    run_stale=bool(running and clock-parse(running['recorded_at'])>timedelta(minutes=stale_minutes))
    if running:status='running_stale'if run_stale else'running'
    elif not markets:status='readiness_checked_market_not_yet_scanned'if probes else'waiting_first_run'
    elif latest and latest['payload']['outcome']!='succeeded':status='degraded'
    elif stale_after and clock>=parse(stale_after):status='stale'
    else:status='healthy'
    return {'schema':'etf.monitor_runtime.v1','generated_at':stamp,'status':status,'record_count':len(rows),
      'last_attempt_at':beginnings[-1]['recorded_at']if beginnings else None,
      'last_success_at':last_success,'last_market_check_at':markets[-1]['recorded_at']if markets else None,
      'last_market_review_summary':markets[-1]['payload'].get('review_summary')if markets else None,
      'last_source_probe_at':probes[-1]['recorded_at']if probes else None,
      'source_probe_outcome':probes[-1]['payload']['outcome']if probes else None,
      'failed_sources':failures,'last_error':(latest['payload'].get('error')or '; '.join(s['name']+': '+str(s.get('error')or 'source access failed')for s in failures)or None)if latest else None,
      'stale_after':stale_after,'stale_after_minutes':stale_minutes,
      'market_check_freshness':'never_successfully_checked'if not last_success else'stale'if clock>=parse(stale_after)else'within_window',
      'active_run':running['payload']if running else None,'active_run_stale':run_stale,
      'ledger_head_hash':rows[-1]['record_hash']if rows else None,
      'semantics':'last_success_at means a complete successful content-reviewed market check. Source HTTP readiness never advances it. Hashes provide local auditability, not trusted external timestamps.'}

def recover(run_id,reason,folder=DEFAULT,at=None,confirm_not_running=False):
    """An operator may close a stale abandoned run; never auto-break an active lock."""
    if not reason or confirm_not_running is not True:raise ValueError('Recovery requires reason and explicit confirmation that the owner is no longer running')
    state=view(folder,at)
    if not state['active_run_stale']or state['active_run']['run_id']!=run_id:raise ValueError('Only the matching stale active run can be recovered')
    return terminal(run_id,{'recovery_reason':reason},folder,at,forced_error='Abandoned stale run recovered: '+reason)

def known_ledger_updates():
    from v4_evidence import build_view,read_records
    current=build_view();last_review=current.get('last_review');review_seq=last_review['sequence']if last_review else 0
    seq={r['record_hash']:r['sequence']for r in read_records()};out=[]
    for event in current['events']:
        a=event.get('actual')
        if a and seq.get(a['record_hash'],10**9)<=review_seq:
            out.append({'id':event['event_id'],'title':event['event_id']+' 已有结果并经过后续分析复核','url':a['provenance']['source_url'],
                        'published_date':a.get('released_date',a.get('released_at','')[:10]),'recorded_at':a['recorded_at'],'origin':'reviewed_evidence_ledger_not_new_probe_discovery'})
    seen={x['url'].rstrip('/')for x in out}
    for r in read_records():
        if r['kind']!='evidence_revision'or r['sequence']>review_seq:continue
        p=r['payload'];prov=p.get('provenance',{});url=prov.get('source_url')
        if not url or url.rstrip('/')in seen:continue
        seen.add(url.rstrip('/'));out.append({'id':'revision_'+str(r['sequence']),'title':p['reason'],'url':url,
            'published_date':prov.get('published_date',prov.get('published_at','')[:10]),'recorded_at':r['recorded_at'],'origin':'reviewed_evidence_revision'})
    return out

def sync_state(folder=DEFAULT,state_path=None):
    state_path=Path(state_path or ROOT/'v4/monitor_state.json');state=load(state_path)if state_path.exists()else{}
    health=view(folder,cadence_minutes=state.get('cadence_minutes',30));state.update({k:health[k]for k in ['last_attempt_at','last_success_at','last_market_check_at','last_source_probe_at','source_probe_outcome','failed_sources','last_error','stale_after','stale_after_minutes','market_check_freshness']})
    state['runtime_status']=health['status'];state['runtime_record_count']=health['record_count'];state['runtime_ledger_head_hash']=health['ledger_head_hash'];state['last_market_review_summary']=health['last_market_review_summary']
    if state_path.resolve()==(ROOT/'v4/monitor_state.json').resolve():state['confirmed_updates']=known_ledger_updates()
    state.setdefault('pending_verification',[]);state['evidence_policy']='Probe response bodies are unverified raw artifacts, not newly confirmed news; no financial model writes.'
    atomic_json(state_path,state);atomic_json(Path(folder)/'status.json',health);return health

def official_sources():
    from v4_evidence import build_view
    source={s['id']:s for s in build_view()['snapshot']['sources']}
    wanted=[('Microsoft','MSFT_Q4_PR'),('Amazon','AMZN_Q2'),('Alphabet/SEC','GOOGL_Q2'),('Meta','META_Q3'),('NVIDIA','NVDA_Q2'),('TSMC','TSM_Q3'),('Micron','MU_Q4'),('SK hynix','SK_Q3_RESULTS'),('Samsung','SAMSUNG_GUIDE'),('Federal Reserve','FOMC_CAL'),('BLS CPI','CPI_SEP'),('BEA PCE','PCE_AUG')]
    return [{'name':name,'source_id':key,'url':source[key]['url']}for name,key in wanted if key in source]

def probe_one(source,artifact_folder):
    row={**source,'attempted_at':utcnow(),'scope':'source_access_only','access_channel':'python_urllib_direct','content_checked':False,'evidence_status':'raw_access_artifact_pending_content_review','alternative_web_or_connector_access':'not_tested_by_this_probe'}
    try:
        req=urllib.request.Request(source['url'],headers={'User-Agent':'Mozilla/5.0 ETFResearchSourceAccess/1.0','Accept':'text/html,application/pdf,application/json;q=0.9,*/*;q=0.5'})
        with urllib.request.urlopen(req,timeout=18)as response:
            body=response.read(65536);code=response.status;mime=response.headers.get('Content-Type','');final_url=response.geturl()
        if not body:raise ValueError('Empty response body')
        title=body[:8000].lower();challenge=any(t in title for t in [b'<title>access denied',b'<title>just a moment',b'<title>403 forbidden'])
        path=Path(artifact_folder)/(source['source_id']+'.sample.bin');path.write_bytes(body)
        row.update(ok=200<=code<300 and not challenge,http_status=code,content_type=mime,final_url=final_url,sample_bytes=len(body),sample_sha256=hashlib.sha256(body).hexdigest(),sample_file=str(path.relative_to(ROOT)),
                   error='Suspected access challenge; content not accessible'if challenge else None)
    except urllib.error.HTTPError as e:row.update(ok=False,http_status=e.code,error=str(e))
    except Exception as e:row.update(ok=False,http_status=None,error=str(e))
    row['completed_at']=utcnow();return row

def probe(folder=DEFAULT):
    started=begin('source_readiness',folder);rid=started['payload']['run_id'];raw=ROOT/'v5/monitor_probe_raw'/rid;raw.mkdir(parents=True,exist_ok=False)
    try:
        sources=official_sources()
        with ThreadPoolExecutor(max_workers=4)as pool:results=list(pool.map(lambda s:probe_one(s,raw),sources))
        report={'schema':'etf.monitor_source_probe.v1','run_id':rid,'scope':'HTTP accessibility of selected saved official URLs only, not latest-news coverage or earnings verification',
                'content_review_performed':False,'coverage_note':'No claim of scanning all market news. A200response only means sampled body access; it is not source-content verification.',
                'started_at':started['recorded_at'],'completed_at':utcnow(),'sources':results,'known_reviewed_evidence_updates':known_ledger_updates(),
                'financial_model_changed':False,'new_confirmed_news':[]}
        terminal(rid,report,folder);atomic_json(ROOT/'v5/monitor_probe.json',report);sync_state(folder)
        print(json.dumps({'scope':'access_readiness_only','sources':len(results),'reachable':sum(r['ok']for r in results),'failed':sum(not r['ok']for r in results),'market_check_completed':False}))
        return report
    except Exception as e:
        terminal(rid,{},folder,forced_error=str(e));sync_state(folder);raise

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('command',choices=['begin','finish','fail','status','probe','recover']);p.add_argument('--kind',choices=sorted(KINDS),default='market_check');p.add_argument('--run-id');p.add_argument('--input');p.add_argument('--error');p.add_argument('--reason');p.add_argument('--confirm-not-running',action='store_true');p.add_argument('--folder',default=str(DEFAULT));a=p.parse_args()
    if a.command=='probe':probe(a.folder)
    elif a.command=='begin':print(json.dumps(begin(a.kind,a.folder)['payload']))
    elif a.command=='recover':
        if not a.run_id:p.error('--run-id required')
        recover(a.run_id,a.reason,a.folder,confirm_not_running=a.confirm_not_running);print(json.dumps(sync_state(a.folder)))
    elif a.command in ['finish','fail']:
        if not a.run_id:p.error('--run-id required')
        if a.command=='finish'and not a.input:p.error('--input required')
        terminal(a.run_id,load(a.input)if a.input else{},a.folder,forced_error=a.error or 'Unspecified monitor failure'if a.command=='fail'else None)
        print(json.dumps(sync_state(a.folder)))
    else:print(json.dumps(sync_state(a.folder),ensure_ascii=False,indent=2))
