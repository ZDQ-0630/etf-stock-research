"""Source-labelled operating driver -> per-share earnings proxy -> price sensitivity.

The model uses a same-season quarter a year ahead, not annualized quarterly profits.
All forward parameters are explicit analyst assumptions; no consensus forecast is fitted.
"""
from pathlib import Path
from datetime import datetime, timezone
import argparse, json, math, hashlib

ROOT=Path(__file__).resolve().parent

def sec_operating_base(symbol,period_end,expected_revenue,cutoff='2026-10-27'):
    """Prefer same-quarter direct facts; Q4 can be annual minus matching FY-YTD.

    Match start/end/unit/FY and verify derived revenue against the earnings release.
    This is source-traceable arithmetic, not independent issuer-data verification.
    """
    path=ROOT/'v2/raw'/f'sec_{symbol}.json';raw=json.loads(path.read_text(encoding='utf8'))
    facts=raw['facts']['us-gaap'];revtag='Revenues'if 'Revenues'in facts else 'RevenueFromContractWithCustomerExcludingAssessedTax'
    def records(tag):
        return [r for r in facts[tag]['units']['USD']if r.get('start')and r.get('filed','9999')<=cutoff]
    ops=records('OperatingIncomeLoss')
    revenues=[{**r,'_revenue_tag':tag}for tag in ['Revenues','RevenueFromContractWithCustomerExcludingAssessedTax']if tag in facts for r in records(tag)]
    def match(revenue_rows,op):
        candidates=[r for r in revenue_rows if r['start']==op['start']and r['end']==op['end']and r.get('fy')==op.get('fy')and r.get('accn')==op.get('accn')]
        return max(candidates,key=lambda r:r['filed'])if candidates else None
    direct=[r for r in ops if r['end']==period_end and 70<=(datetime.fromisoformat(r['end'])-datetime.fromisoformat(r['start'])).days<=115]
    evidence=[];opvalue=None;revvalue=None;method=None
    for op in sorted(direct,key=lambda r:r['filed'],reverse=True):
        rev=match(revenues,op)
        if rev:
            opvalue=op['val'];revvalue=rev['val'];method='direct_same_quarter';evidence=[{'tag':'OperatingIncomeLoss',**op},{'tag':rev['_revenue_tag'],**rev}];break
    if opvalue is None:
        annuals=[r for r in ops if r['end']==period_end and 340<=(datetime.fromisoformat(r['end'])-datetime.fromisoformat(r['start'])).days<=380]
        for annual in sorted(annuals,key=lambda r:r['filed'],reverse=True):
            prior=[r for r in ops if r['start']==annual['start']and r.get('fy')==annual.get('fy')and r['end']<period_end and 240<=(datetime.fromisoformat(r['end'])-datetime.fromisoformat(r['start'])).days<=300]
            if not prior:continue
            ytd=max(prior,key=lambda r:(r['end'],r['filed']));revannual=match(revenues,annual);revytd=match(revenues,ytd)
            if not revannual or not revytd:continue
            opvalue=annual['val']-ytd['val'];revvalue=revannual['val']-revytd['val'];method='Q4_annual_minus_same_fiscal_year_9months'
            evidence=[{'tag':'OperatingIncomeLoss',**annual},{'tag':'OperatingIncomeLoss',**ytd},{'tag':revannual['_revenue_tag'],**revannual},{'tag':revytd['_revenue_tag'],**revytd}];break
    if opvalue is None or revvalue is None:raise ValueError(symbol+': no comparable operating income')
    if abs(revvalue/1e9-expected_revenue)>1e-6:raise ValueError(symbol+': SEC revenue does not reconcile to current earnings release')
    source={'id':'SEC_'+symbol+'_OP','title':symbol+' SEC companyfacts operating income bridge','url':f"https://data.sec.gov/api/xbrl/companyfacts/CIK{int(raw['cik']):010d}.json",
            'published':max(r['filed']for r in evidence),'source_kind':'primary_SEC_structured_facts','retrieved_at':'2026-10-27 saved snapshot'}
    return {'operating_income_bn':opvalue/1e9,'revenue_bn':revvalue/1e9,'method':method,'records_USD':evidence,
            'raw_file':str(path.relative_to(ROOT)),'raw_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'source':source,
            'reconciliation':'SEC same-quarter/derived-quarter revenue equals separately saved quarterly release revenue; no quarter annualization.',
            'limitation':'Q4 subtraction spans annual and nine-month filings; no additional assumption that all nonoperating/tax items are recurring.'}

def operating_bridge(revenue_growth, base_margin, future_margin, share_growth=0., multiple_ratio=1., years=1):
    values=[revenue_growth,base_margin,future_margin,share_growth,multiple_ratio,years]
    if not all(isinstance(x,(int,float))and math.isfinite(x)for x in values):raise ValueError('Nonfinite driver')
    if revenue_growth<=-1 or share_growth<=-1 or not 0<base_margin<=1 or not 0<future_margin<=1 or multiple_ratio<=0 or years<1 or years>10:
        raise ValueError('Positive profit and comparable share count/margin required')
    revenue_factor=(1+revenue_growth)**years
    margin_factor=future_margin/base_margin
    share_factor=1/(1+share_growth)**years
    earnings_proxy_factor=revenue_factor*margin_factor*share_factor
    return {'revenue_factor':revenue_factor,'margin_factor':margin_factor,'share_factor':share_factor,
            'operating_profit_per_share_factor':earnings_proxy_factor,
            'conditional_normalized_eps_factor':earnings_proxy_factor,
            'conditional_price_factor':earnings_proxy_factor*multiple_ratio,
            'eps_proxy_condition':'Only if the recurring tax/interest/nonoperating bridge is proportionally unchanged; not GAAP EPS.',
            'price_proxy_condition':'Only under the supplied equity multiple ratio and comparable normalized EPS basis; not intrinsic fair value.'}

def fund_contribution(holdings,price_factors,fund,uncovered_factor=None):
    rows=[r for r in holdings if r['fund']==fund]
    if not rows:raise ValueError('No holdings snapshot for fund')
    latest=max(r['date']for r in rows)
    rows=[r for r in rows if r['date']==latest]
    if len({r['symbol']for r in rows})!=len(rows):raise ValueError('Duplicate company in the same holdings snapshot')
    if any(isinstance(r['weight'],bool)or not isinstance(r['weight'],(int,float))or not math.isfinite(r['weight'])or r['weight']>1 or(r['weight']<0 and not(r['symbol']in ['Other/Cash','Cash','CASH']and r['weight']>=-.001))for r in rows):raise ValueError('Invalid holding weight; only small labelled cash/rounding adjustments may be signed')
    if uncovered_factor is not None and(isinstance(uncovered_factor,bool)or not isinstance(uncovered_factor,(int,float))or not math.isfinite(uncovered_factor)or uncovered_factor<0):raise ValueError('Invalid uncovered price factor')
    if any(isinstance(price_factors[r['symbol']],bool)or not isinstance(price_factors[r['symbol']],(int,float))or not math.isfinite(price_factors[r['symbol']])or price_factors[r['symbol']]<0 for r in rows if r['symbol']in price_factors):raise ValueError('Invalid company price factor')
    covered=[{'symbol':r['symbol'],'weight':r['weight'],'price_factor':price_factors[r['symbol']],
              'return_contribution':r['weight']*(price_factors[r['symbol']]-1),'holding_date':r['date']}
             for r in rows if r['symbol']in price_factors]
    coverage=sum(r['weight']for r in covered)
    if coverage>1+1e-8:raise ValueError('Covered weight exceeds NAV')
    contribution=sum(r['return_contribution']for r in covered)
    residual=max(0.,1-coverage)
    return {'fund':fund,'holding_snapshot_date':latest,'cash_rounding_adjustment_weight':sum(r['weight']for r in rows if r['symbol']in ['Other/Cash','Cash','CASH']),'covered_weight':coverage,'uncovered_weight':residual,'covered_price_return_contribution':contribution,
            'whole_fund_price_factor':None if uncovered_factor is None else 1+contribution+residual*(uncovered_factor-1),
            'uncovered_price_factor_assumption':uncovered_factor,'constituents':covered,
            'full_fund_eps_growth':None,'full_fund_eps_status':'Unavailable: no complete comparable earnings-weighted base',
            'aggregation_basis':'Initial NAV-weighted stock price-return contributions, fixed shares/composition, no rebalancing; not NAV-weighted EPS growth.'}

def build(evidence=None):
    evidence=evidence if evidence is not None else json.loads((ROOT/'v3/current_evidence.json').read_text(encoding='utf8'))
    holdings=json.loads((ROOT/'v2/model/holdings.json').read_text(encoding='utf8'))
    source_map={s['id']:s for s in evidence['sources']}
    warnings={
      'MSFT':['现金PPE、融资租赁与经营租赁口径不同；报告capex重分类不等于经济投资减少。','Azure约45%指引是云分部固定汇率增速，不是全公司收入或EPS增速。'],
      'AMZN':['TTM自由现金流与本季利润期间不同，不能直接相除或混为本季现金转化。','Anthropic等投资重估收益不属于持续经营利润；AWS收入不能与AI年化run-rate重复相加。'],
      'GOOGL':['本季巨额投资收益不作为正常化EPS基准。','股权融资可能摊薄每股收益；假设股数变化须单独填写。'],
      'META':['报告经营利润含约9.9十亿美元诉讼费用；不自动剔除或假定此费用必不再发生。','公司的FCF包含融资租赁本金，不能与其他公司简单横比。'],
      'TSM':['本季经营利润率用于同季敏感性；Q4毛利率指引不是经营利润率指引。','美元收入和台币财报利润/每股收益的货币转换需另行建模。'],
      '000660.KS':['净利润受非经营项目影响；经营利润/股不等于净EPS，税与非经营因素须另核对。','存储高景气利润率不能假定永久；首年盈利应考虑价格与产能正常化。'],
      'NVDA':['SEC同季经营利润与本季收入匹配；未用75%毛利率代替经营利润率。','应收/存货与战略投资吸收现金，供应商营收不能重复计为终端客户ROI。'],
      'MU':['Q4经营利润由全年减同财年前三季推导；收入同样相减并与Q4公告核对。','存储高景气经营利润率不能永续外推；长期合同不消除价格/扩产周期。'],
    }
    companies=[];unavailable=[]
    for b in evidence['business']:
        actual=b.get('actual',{});revenue=actual.get('revenue');op=actual.get('operating_income',actual.get('total_operating_income'));sec_evidence=None
        if b['symbol']in ['NVDA','MU'] and op is None:
            try:
                sec_evidence=sec_operating_base(b['symbol'],b['period_end'],revenue)
                op=sec_evidence['operating_income_bn'];source_map[sec_evidence['source']['id']]=sec_evidence['source']
                b={**b,'source_ids':b['source_ids']+[sec_evidence['source']['id']]}
            except ValueError:sec_evidence=None
        margin=op/revenue if op is not None and revenue else (actual.get('operating_margin_pct',0)/100 or None)
        if revenue is None or margin is None or not 0<margin<=1:
            unavailable.append({'symbol':b['symbol'],'reason':'缺少同期间全公司实际收入与经营利润/经营利润率；不使用毛利率代替净利率或将预告当实际。',
                                'period':b.get('period'),'source_ids':b['source_ids'],'guidance':b.get('guidance',{}),'actual_available':actual})
            continue
        specs=[('stress',-.10,-.03,.01,.8),('unchanged',0.,0.,0.,1.),('improvement',.10,.02,0.,1.1)]
        scenarios=[]
        for name,g,delta,shares,multiple in specs:
            future_margin=max(.001,min(.99,margin+delta))
            drivers={'revenue_growth':g,'base_margin':margin,'future_margin':future_margin,'share_growth':shares,'multiple_ratio':multiple}
            scenarios.append({'id':name,'label':{'stress':'收入与利润受压','unchanged':'各项不变基准','improvement':'收入与利润改善'}[name],
                              'driver_status':'manual_stress_assumptions_not_consensus_or_management_guidance','drivers':drivers,
                              'calculation':operating_bridge(**drivers),
                              'assumption_rationale':'预先固定的压力测试：收入−10%/0/+10%，经营利润率−3/0/+2个百分点，股数+1%/0/0，倍数0.8/1/1.1。仅检验传导，不赋概率或声称最可能。'})
        cash={k:v for k,v in actual.items()if any(t in k for t in ['cfo','fcf','capex','cash_ppe','lease','inventory_cash_use','accounts_receivable_cash_use'])}
        companies.append({'symbol':b['symbol'],'period':b['period'],'period_end':b['period_end'],'unit':b['unit'],
                          'base_revenue':revenue,'base_operating_income':op,'base_operating_margin':margin,
                          'margin_calculation':(sec_evidence['method']+' operating income / same-quarter revenue')if sec_evidence else ('reported operating_income / same-period revenue'if op is not None else 'reported operating_margin_pct /100'),
                          'sec_calculation_evidence':sec_evidence,
                          'source_ids':b['source_ids'],'sources':[source_map[s]for s in b['source_ids']],
                          'fact_retrieved_at':b.get('fact_retrieved_at',max(source_map[s].get('retrieved_at',evidence['retrieved_at'])for s in b['source_ids'])),'fact_posture':'source_labelled_snapshot_each_company_has_own_retrieval_time',
                          'cash_facts':cash,'management_guidance':b.get('guidance',{}),'guidance_status':'Management guidance is not a forecast for all bridge drivers.',
                          'economic_flags':warnings.get(b['symbol'],[]),'scenarios':scenarios,
                          'forecast_horizon':'同季一年后利润/股的敏感性；未将本季乘4，未预测全年净利润。',
                          'normalization_adjustments_applied':0,'net_eps_base':None,'tax_interest_nonoperating_bridge':'unverified_constant-proportional-bridge assumption required'})
    fund_scenarios=[]
    for case in ['stress','unchanged','improvement']:
        factors={c['symbol']:next(s['calculation']['conditional_price_factor']for s in c['scenarios']if s['id']==case)for c in companies}
        for fund in ['QQQM','SMH','SOXX','DRAM']:
            row=fund_contribution(holdings,factors,fund);row['scenario_id']=case;fund_scenarios.append(row)
    result={'schema':'v4.operating_bridge.v1','built_utc':datetime.now(timezone.utc).isoformat(),
            'source_evidence_retrieved_at':evidence['retrieved_at'],'source_sha256':hashlib.sha256(json.dumps(evidence,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest(),
            'status':'limited_coverage_analyst_sensitivity_not_forecast','companies':companies,'unavailable_companies':unavailable,
            'fund_scenarios':fund_scenarios,'sources':list(source_map.values()),
            'formulas':{'per_share_operating_factor':'(1+revenue_growth)*(future_operating_margin/base_operating_margin)/(1+share_growth)',
                        'conditional_price_factor':'conditional_normalized_eps_factor*equity_multiple_ratio',
                        'covered_return_contribution':'sum(initial_NAV_weight*(company_price_factor-1))'},
            'limitations':['经营利润/股不等于净EPS；税、利息、非经营项目和股权结构必须另审。','capex与租赁影响现金及未来折旧，但本模型未将capex机械扣为当期费用。',
                           'SBC费用与股数摊薄可能同时存在；没有用SBC/CFO当作股数增速。','八家可用公司只代表有限覆盖；未覆盖权重不自动视为零收益。',
                           '不同公司参考季度不同；未将跨季度盈利直接相加或构造整只基金PE。','压力参数属于手动假设，不由当前营业增长率机械外推。']}
    out=ROOT/'v4/bridge.json';out.parent.mkdir(exist_ok=True);out.write_text(json.dumps(result,ensure_ascii=False,indent=2,allow_nan=False),encoding='utf8')
    print(json.dumps({'companies':len(companies),'unavailable':[r['symbol']for r in unavailable],
                      'coverage':{r['fund']:r['covered_weight']for r in fund_scenarios if r['scenario_id']=='unchanged'}},ensure_ascii=False))
    return result

if __name__=='__main__':build()
