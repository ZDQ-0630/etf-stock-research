"""Evidence-informed, explicitly discretionary starting scenarios; never a fitted forecast."""
from pathlib import Path
from datetime import datetime, timezone
import json, hashlib, math
ROOT=Path(__file__).resolve().parent

def operating_path(g1,growth,margin0,margin1,shares,years=3,multiple=.9):
    if not all(math.isfinite(x)for x in [g1,growth,margin0,margin1,shares,years,multiple]) or min(g1,growth,shares)<=-1 or not 0<margin0<=1 or not 0<margin1<=1 or not 1<=years<=10 or multiple<=0:
        raise ValueError('Invalid operating path inputs')
    op=(1+g1)*(1+growth)**(years-1)*margin1/margin0/(1+shares)**years
    return {'per_share_operating_factor':op,'conditional_price_factor':op*multiple}

def build():
    raw=ROOT/'v5/expectations_sources.json';x=json.loads(raw.read_text(encoding='utf8'))
    funds={f['fund']:f for f in x['funds']}
    # Research judgement. Deliberately not optimized against historical returns.
    specs={
      'QQQM':(.20,.12,[.10,.30],[.08,.18],'部分年度盈利预测约29%/11%，但只覆盖36.85% NAV，且财年混合。结合核心云公司与广告业务，采用20%/12%的归一化整篮子情景；不是统计外推或整只基金一致预期。'),
      'SMH':(.35,.18,[.15,.50],[.05,.25],'可用年度预测部分覆盖约91% NAV，两个财年转移约39%/24%；另iFAST单一机构2027年盈利增长40%。采用35%/18%，为远期样本变薄、存储正常化与估值风险留出余地。'),
      'SOXX':(.30,.15,[.10,.45],[.00,.22],'可用年度预测部分覆盖约90% NAV，两个财年转移约32%/18%。采用30%/15%的分析情景；成分、盈利权重和各公司财年仍有差异。'),
      'DRAM':(.15,-.05,[-.20,.40],[-.20,.10],'同口径可用年度预测仅MU、覆盖28.12% NAV；MU后续财年先+17%再-12%，韩国持仓仍有股权单位/预测覆盖缺口。15%/-5%只是存储正常化风险情景，证据不足以称为整只基金基准预测。')}
    ref={}
    for fund,(g1,g2,r1,r2,reason)in specs.items():
        f=funds[fund]
        ref[fund]={'g1':g1,'growth':g2,'multiple':.9,'label':'有来源的分析参考情景（DRAM证据薄弱）'if fund=='DRAM'else'有来源的归一化分析参考情景',
          'asof':x['information_cutoff'],'source_ids':['NASDAQ_ANNUAL_'+fund,'ANALYST_NORMALIZATION_V5']+(['IFAST_SMH_OCT02']if fund=='SMH'else[]),
          'input_type':'analyst_scenario_not_full_fund_market_consensus','first_year_range':r1,'later_year_range':r2,
          'range_type':'analyst_sensitivity_bounds_not_confidence_or_probability_interval',
          'rationale':reason,'coverage_nav_weight':f['annual_fiscal_reference']['coverage_nav_weight'],
          'period_caveat':'首年/后续为从估值锚起算的近似情景年；原始财年预测不能精确拼成日历NTM。',
          'valuation_rationale':'终值倍数0.90人为假设收缩10%；不是市场共识，不根据回测寻优。',
          'operating_to_equity_caveat':'基金每股盈利代理；税/非经营项目、成分调整、分红及费用尚未完整桥接。',
          'reference_reliability':'weak_partial_memory_proxy'if fund=='DRAM'else'provisional_analyst_normalization'}
    # Same-season revenue path. Near-term source windows are displayed separately;
    # these decelerating annual paths are underwriting judgements, not consensus.
    company_specs={
      'NVDA':(.70,.35,'FY28收入增长约70%的管理层展望提供首年锚；之后减半到35%是模型假设。',None),
      'MSFT':(.17,.13,'近几季营收预期约18%，FY27双位数管理层展望；采用17%并降至13%。',None),
      'AMZN':(.15,.12,'参考未来财季的公司营收预测，AWS增速不能当作全公司增速；采用15%/12%的分析路径。',None),
      'GOOGL':(.20,.15,'近期公司营收预期约25%；首年取20%，后续15%，排除投资收益对EPS的污染。',None),
      'META':(.20,.15,'近期公司营收预期约23%；取20%/15%，capex折旧压力另由利润率情景承接。',None),
      'TSM':(.40,.25,'近期美元营收预期约50%，2026全年管理层展望约44%；未来取40%/25%，不是把2026指引错当2027指引。',None),
      'MU':(.75,.00,'近期三季营收预期超过150%；首年主动降至75%、后续0%，未来经营利润率设60%检验高峰正常化。',.60),
      '000660.KS':(.30,.00,'Q3实际已更新，但缺少可比全年度一致预期；30%/0%仅为存储风险假设，未来经营利润率设65%。',.65)}
    company_ref={s:{'revenue_growth':a,'later_revenue_growth':b,'future_margin_override':m,'share_growth':0.,'multiple_ratio':.9,'rationale':r,
      'type':'analyst_annual_same_season_path_not_reported_consensus','shares_status':'0% is a neutral assumption, not a verified dilution forecast'}for s,(a,b,r,m)in company_specs.items()}
    result={'schema':'etf.expectation_reference.v1','version':'2026-10-28-references-v1','built_at':datetime.now(timezone.utc).isoformat(),
      'source_data_sha256':hashlib.sha256(raw.read_bytes()).hexdigest(),'reference_inputs_by_symbol':ref,'company_inputs_by_symbol':company_ref,
      'source_data':x,'extra_sources':[{'id':'IFAST_SMH_OCT02','url':'https://fsm.global/sg/article/rcms397280','title':'iFAST Research 2026-10-02：SMH底层2027盈利增长40%（单一机构）','type':'single_institution_forecast_not_consensus'}],
      'policy':['原始预期/公司指引/分析情景分别展示；没有由代码优化增长率或给情景赋概率。','28家数据已取回，但Nasdaq asOf为空、EPS调整口径不全，取回时间不等于预测更新时间。','历史检验不包含这些新前瞻参数，不能声称这些数值已获得回测验证。','营收、经营利润/股、归一化EPS和ETF价格是不同指标，不直接互换。']}
    p=ROOT/'v5/reference_inputs.json';p.write_text(json.dumps(result,ensure_ascii=False,indent=2,allow_nan=False),encoding='utf8')
    return result
if __name__=='__main__':
    r=build();print(json.dumps({'funds':len(r['reference_inputs_by_symbol']),'company_paths':len(r['company_inputs_by_symbol'])}))
