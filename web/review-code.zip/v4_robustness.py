"""Prespecified selection/peak/bin sensitivity, using frozen V3 inputs only.

python v4_robustness.py
python v4_robustness.py --self-test
No network, fitting, best-variant selection, or side effects on import.
"""
from pathlib import Path
from datetime import datetime, timezone
import argparse, hashlib, json, unittest
import numpy as np
import pandas as pd
from v3_engine import load_chart, state_frame, monthly_entries, calendar_endpoint, nonoverlap, wealth

ROOT=Path(__file__).resolve().parent
BINS=['0–5%','5–10%','10–15%','15–20%','20%+']
OFFSETS=[0,21,63,126,252]
SYMBOLS=['QQQ','QQQM','SMH','SOXX','SPY']

def file_hash(path):return hashlib.sha256(path.read_bytes()).hexdigest()

def select_offset(candidates,endpoints,offset):
    """Offset is a number of underlying trading rows, NOT candidate rows."""
    if not candidates:return []
    boundary=candidates[0]+offset
    return nonoverlap([j for j in candidates if j>=boundary],endpoints)

def bin_labels(drawdown):
    return pd.cut((-drawdown).round(12),[-1e-12,.05,.10,.15,.20,1.01],labels=BINS,right=False)

def simple_stats(values):
    if not values:return {'count':0,'mean_sgd':None,'median_sgd':None,'min_sgd':None,'max_sgd':None}
    return {'count':len(values),'mean_sgd':float(np.mean(values)),'median_sgd':float(np.median(values)),
            'min_sgd':float(min(values)),'max_sgd':float(max(values))}

def run(config=None,output_dir=None):
    out=Path(output_dir)if output_dir else ROOT/'v4';out.mkdir(parents=True,exist_ok=True)
    config=Path(config)if config else ROOT/'v3_config.json'
    c=json.loads(config.read_text(encoding='utf8'))
    if (c['fixed_wait_sessions'],c['dca_tranches'],c['minimum_calendar_holding_years'])!=(21,6,3):
        raise ValueError('This prespecified sensitivity requires21-session wait,6 monthly tranches and3 calendar years.')
    model=ROOT/c.get('model_output_dir','v3/model')
    saved=json.loads((model/'protocol.json').read_text(encoding='utf8'))
    if saved['config']!=c:raise ValueError('Frozen V3 macro/model outputs do not match the configuration; rebuild V3 first.')
    macro_path=model/'macro_history.csv'
    source_paths={s:ROOT/c.get('input_chart_paths',{}).get(s,f'v2/raw/yahoo_{s}.json')for s in SYMBOLS}
    protocol={
      'schema':'v4_selection_robustness.protocol.v1',
      'frozen_before_calculation_utc':datetime.now(timezone.utc).isoformat(),
      'price_cutoff':c['asof'],'symbols':SYMBOLS,'peak_definitions':['running','rolling252'],
      'state_selection':'Each definition own latest completed-close bin plus each available adjacent bin; no omitted unfavorable variant.',
      'offsets_trading_sessions':OFFSETS,
      'offset_definition':'For each symbol/peak/bin, first mature cash-eligible candidate underlying trading-row index plus offset. Start at first candidate on/after that boundary, then greedy nonoverlap.',
      'primary_comparison':'Wait21 sessions after immediate next-open entry minus immediate; both liquidate same endpoint.',
      'common_endpoint':'Six calendar-month DCA schedule final planned entry plus3 calendar years, rolled forward to first session.',
      'eligibility':'All schedule dates and common endpoint mature; cash rate observed through final planned DCA entry. Each peak feature must be known at decision close.',
      'currency':'USD wealth scaled to S$3000 at constant FX; not historical SGD return.',
      'budget_sgd':c['budget_sgd'],'fixed_fee_usd':c['fixed_fee_usd_per_order'],'proportional_bps':c['cost_bps_per_trade'],
      'cash_source':'Frozen V3 lagged IRX conversion, not a tradable bill total-return series.',
      'posture':'Retrospective exploratory sensitivity. Protocol frozen for this computation after V3 history was seen. No optimization, p-values, probability calibration or confidence intervals.',
      'dependence':'Variants share many dates and market episodes; variant count is not independent sample count.',
      'input_hashes':{str(p.resolve().relative_to(ROOT)):file_hash(p)for p in [config,macro_path,*source_paths.values()]}
    }
    encoded=json.dumps(protocol,ensure_ascii=False,sort_keys=True,indent=2)
    (out/'robustness_protocol.json').write_text(encoded,encoding='utf8')
    protocol_sha=hashlib.sha256(encoded.encode('utf8')).hexdigest()
    rates_all=pd.read_csv(macro_path,index_col=0,parse_dates=True).cash_rate
    v3pairs=json.loads((model/'paired_comparisons.json').read_text(encoding='utf8'))
    rows=[];checks=[]
    for symbol,path in source_paths.items():
        f=load_chart(path,c['asof'])
        if symbol=='SMH':f=f.loc['2011-12-20':]
        f=state_frame(f);rates=rates_all.reindex(f.index)
        eligible=[];endpoints={};plans={}
        for j in range(len(f)-1):
            buys=monthly_entries(f.index,j,c['dca_tranches'])
            if buys is None:continue
            end=calendar_endpoint(f.index,buys[-1],years=c['minimum_calendar_holding_years'])
            if end is None:continue
            if rates.iloc[j:buys[-1]].isna().any():continue
            eligible.append(j);endpoints[j]=end;plans[j]=buys
        cache={}
        def result(j):
            if j in cache:return cache[j]
            end=endpoints[j];capital=c['budget_sgd']/c['usdsgd_reference']
            a=wealth(f,j,end,[j+1],rates,c['cost_bps_per_trade'],c['fixed_fee_usd_per_order'],capital)
            b=wealth(f,j,end,[j+22],rates,c['cost_bps_per_trade'],c['fixed_fee_usd_per_order'],capital)
            assert a is not None and b is not None
            cache[j]={'decision':str(f.index[j].date()),'immediate_entry':str(f.index[j+1].date()),
                      'wait21_entry':str(f.index[j+22].date()),'common_end':str(f.index[end].date()),
                      'last_planned_dca_entry':str(f.index[plans[j][-1]].date()),
                      'immediate_wealth_factor':a['wealth'],'wait21_wealth_factor':b['wealth'],
                      'difference_sgd':c['budget_sgd']*(b['wealth']-a['wealth']),
                      'immediate_path_max_drawdown':a['max_drawdown'],'wait21_path_max_drawdown':b['max_drawdown']}
            return cache[j]
        for definition,column in [('running','dd'),('rolling252','dd252')]:
            labels=bin_labels(f[column]);current=str(labels.iloc[-1]);ci=BINS.index(current)
            for bi in range(max(0,ci-1),min(len(BINS),ci+2)):
                target=BINS[bi];candidates=[j for j in eligible if labels.iloc[j]==target]
                for offset in OFFSETS:
                    selected=select_offset(candidates,endpoints,offset)
                    assert len(selected)==len(set(selected))
                    assert all(b>endpoints[a]for a,b in zip(selected,selected[1:]))
                    assert not selected or selected[0]>=candidates[0]+offset
                    episodes=[result(j)for j in selected]
                    row={'symbol':symbol,'peak_definition':definition,'current_bin':current,'tested_bin':target,
                         'bin_relation':'current'if bi==ci else('shallower'if bi<ci else'deeper'),
                         'offset_sessions':offset,'base_eligible_candidates':len(candidates),
                         'offset_eligible_candidates':sum(j>=candidates[0]+offset for j in candidates)if candidates else 0,
                         'first_eligible_candidate':str(f.index[candidates[0]].date())if candidates else None,
                         'offset_boundary_date':str(f.index[candidates[0]+offset].date())if candidates and candidates[0]+offset<len(f)else None,
                         **simple_stats([e['difference_sgd']for e in episodes]),'episodes':episodes}
                    rows.append(row)
                    if definition=='running'and bi==ci and offset==0:
                        original=[r for r in v3pairs if r['symbol']==symbol and r['period']=='all'and r['strategy']=='wait21']
                        assert [r['date']for r in original]==[e['decision']for e in episodes],symbol+' baseline dates'
                        assert all(abs(r['extra_sgd_constant_fx']-e['difference_sgd'])<1e-9 for r,e in zip(original,episodes)),symbol+' baseline values'
                        checks.append(symbol+': zero-offset running/current state matches frozen V3 dates and values')
        print(symbol,'complete',flush=True)
    keys=[(r['symbol'],r['peak_definition'],r['tested_bin'],r['offset_sessions'])for r in rows]
    assert len(keys)==len(set(keys))
    checks+=['All variant keys unique','Every selected cohort nonoverlapping and beyond its trading-session boundary',
             'All specified offsets and peak definitions retained, including zero-sample variants']
    summary=[]
    for symbol in SYMBOLS:
        for scope in ['current_bin_only','current_and_adjacent_bins']:
            rr=[r for r in rows if r['symbol']==symbol and (scope!='current_bin_only'or r['bin_relation']=='current')]
            values=[r['mean_sgd']for r in rr if r['mean_sgd']is not None]
            summary.append({'symbol':symbol,'scope':scope,'variants':len(rr),'nonempty_variants':len(values),
                'min_mean_sgd':min(values)if values else None,'max_mean_sgd':max(values)if values else None,
                'sign_changes_across_variants':bool(values and min(values)<0<max(values)),
                'min_cohort_n':min((r['count']for r in rr),default=0),'max_cohort_n':max((r['count']for r in rr),default=0),
                'interpretation':'Range of prespecified descriptive choices, not confidence interval; variants are dependent.'})
    result_payload={'schema':'v4_selection_robustness.v1','protocol':protocol,'protocol_sha256':protocol_sha,
                    'completed_utc':datetime.now(timezone.utc).isoformat(),'rows':rows,'summary':summary,
                    'validation':{'status':'passed','checks':checks,'unit_tests':4},
                    'limits':['Only21-session wait is compared; no strategy search.',
                      'Current-state matched history may not represent future AI business regimes.',
                      'Offsets alter chosen paths and may leave very few mature independent-looking windows.',
                      'No vendor data refetch or independent data verification.']}
    (out/'robustness.json').write_text(json.dumps(result_payload,ensure_ascii=False,indent=2,allow_nan=False),encoding='utf8')
    print(json.dumps(summary,ensure_ascii=False,indent=2))

class SelectionTests(unittest.TestCase):
    def test_offset_is_underlying_sessions_not_candidate_count(self):
        self.assertEqual(select_offset([0,100,200],{0:10,100:110,200:210},21),[100,200])
    def test_shared_endpoint_excluded(self):
        self.assertEqual(select_offset([0,10,11],{0:10,10:15,11:20},0),[0,11])
    def test_no_candidates(self):self.assertEqual(select_offset([],{},252),[])
    def test_rolling_peak_warmup_and_boundary(self):
        x=bin_labels(pd.Series([np.nan,0,-.05,-.10,-.15,-.20]))
        self.assertTrue(pd.isna(x.iloc[0]));self.assertEqual(list(x.iloc[1:]),BINS)

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--self-test',action='store_true');p.add_argument('--config');p.add_argument('--output-dir');args=p.parse_args()
    suite=unittest.defaultTestLoader.loadTestsFromTestCase(SelectionTests)
    passed=unittest.TextTestRunner(verbosity=2).run(suite)
    if not passed.wasSuccessful():raise SystemExit(1)
    if not args.self_test:run(args.config,args.output_dir)
