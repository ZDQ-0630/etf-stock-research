# 可复现历史图

网站图与分布由原始收盘序列直接重算，算法版本为price-close-running-peak-forward-window-v1。该包包含原始快照data.json、Python标准库脚本及网站文件，无需付费API。

运行 `python reproduce.py --symbol QQQM --horizon 126`，生成结果JSON和可在浏览器打开的HTML图。

网站导出自己的历史快照后，运行 `python reproduce.py --input 你的历史快照.json --symbol QQQM --horizon 126`；使用与导出时相同的窗口可核对网站结果。数据是价格口径，不含分红。日度窗口重叠，不把样本量当独立机会或预测概率。

如需本地运行所有网页，可用 `python -m http.server 8000`，然后浏览器打开localhost:8000。数据更新仅在本浏览器保存。手动数据不被视为已经核实的官方行情；新增价格只改变买价/历史状态，不自动改变估值锚、盈利假设、当前公司事实或研究结论。

复现图不证明未来表现，也不是完整V4模型包；完整模型仍在本地项目提供的ETF_V4_完整复现包.zip中。
